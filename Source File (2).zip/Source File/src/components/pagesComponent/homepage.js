import React from 'react';


function Homepage() {

  //const {currentUser} = useAuth()
    return (
    <div>
    <h1>
    This is Home Page.
    </h1>

  </div>

   );
}
export default Homepage;
